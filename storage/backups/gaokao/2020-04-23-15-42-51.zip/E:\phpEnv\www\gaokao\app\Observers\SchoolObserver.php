<?php

namespace App\Observers;

use App\Models\School;

class SchoolObserver
{
    public function deleting(School $school)
    {

    }
}
