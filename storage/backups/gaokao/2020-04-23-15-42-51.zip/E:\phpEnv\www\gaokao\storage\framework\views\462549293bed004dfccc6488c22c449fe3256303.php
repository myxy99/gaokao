<?php echo e($slot, false); ?>

<?php /**PATH E:\phpEnv\www\gaokao\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>