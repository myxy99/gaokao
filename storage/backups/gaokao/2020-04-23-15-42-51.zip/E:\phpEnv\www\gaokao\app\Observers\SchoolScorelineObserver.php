<?php

namespace App\Observers;

use App\Models\SchoolScoreline;

class SchoolScorelineObserver
{
    public function deleting(SchoolScoreline $schoolScoreline)
    {
    }
}
