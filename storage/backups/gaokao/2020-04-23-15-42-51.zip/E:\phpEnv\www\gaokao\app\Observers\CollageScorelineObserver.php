<?php

namespace App\Observers;

use App\Models\CollageScoreline;

class CollageScorelineObserver
{
    public function deleting(CollageScoreline $collageScoreline)
    {
    }
}
