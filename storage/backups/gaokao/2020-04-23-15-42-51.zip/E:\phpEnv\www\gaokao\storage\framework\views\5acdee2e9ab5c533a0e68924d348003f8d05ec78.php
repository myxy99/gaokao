[<?php echo e($slot, false); ?>](<?php echo e($url, false); ?>)
<?php /**PATH E:\phpEnv\www\gaokao\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>